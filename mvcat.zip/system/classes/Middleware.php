<?php

class Middleware {

    public function run () :bool {

    }

    public function failed () :void {

    }
}