<?php

// app mode (prod/dev)
define("MODE", "dev"); // set this value to 'prod' when using in production mode (case sensitive)

// database configurations
define("HOST", "localhost");

define("USER", "root"); //u727508198_Xoy75

define("DATABASE", "dbm"); //u727508198_6qoJ5

define("PASSWORD", ""); //ftp123F#





/**
 * Auto - generated values below
 * Do not change anything
 */

// base url
define('BASE', getBaseUrl());

// csrf token
define('CSRF', md5(uniqid(rand(), true)));