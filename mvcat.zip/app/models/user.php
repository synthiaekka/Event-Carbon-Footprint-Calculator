<?php

class user extends Model {

    public $table = 'doctors';

    public $primary = 'id';

}